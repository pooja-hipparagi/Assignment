package Testrunner1;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = "src/test/java/Features",
	    glue={"StepDefinition"},
	    plugin= {"pretty","html:target/cucumber.xml"})
		//tags="@scenario2" )



public class TestRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
