package StepDefinition;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class Assgnment {

	WebDriver driver;
	@Given("user is on saucedemo homepage")
	public void user_is_on_saucedemo_homepage() {
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\PoojaHipparagi\\Desktop\\Auto_Cucu\\chromedriver_win32\\chromedriver.exe");
		    driver = new ChromeDriver();
		    driver.get("https://www.saucedemo.com");
		    driver.manage().window().maximize();
		   // driver.findElement(By.xpath("/html/body/div[1]/div/div/div[1]/div/div/ul/li[1]/a")).click(); //Signup
	}

	@Given("user logged in using correct credential")
	public void user_logged_in_using_correct_credential(io.cucumber.datatable.DataTable dataTable) throws InterruptedException {
	  
		List<String> data=dataTable.asList();
		driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[1]/div/form/div[1]/input")).sendKeys(data.get(2));
		driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[1]/div/form/div[2]/input")).sendKeys(data.get(3));
		driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[1]/div/form/input")).click();
		System.out.println("Successfull Login");
		
	}

	@Given("user adds required item to cart")
	public void user_adds_required_item_to_cart() throws InterruptedException 
		
		{
		driver.findElement(By.xpath("/html/body/div/div/div/div[2]/div/div/div/div[1]/div[2]/div[2]/button")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("/html/body/div/div/div/div[2]/div/div/div/div[2]/div[2]/div[2]/button")).click();
		Thread.sleep(5000);
		System.out.println("Required item added to the cart");
		Thread.sleep(5000);
		
	    
	}

	@Given("user proceeds to checkout")
	public void user_proceeds_to_checkout() throws InterruptedException {
	  driver.findElement(By.xpath("/html/body/div/div/div/div[1]/div[1]/div[3]/a")).click();
	  driver.findElement(By.xpath("/html/body/div/div/div/div[2]/div/div[2]/button[2]")).click();
	  Thread.sleep(5000);
	  System.out.println("User has checkd out");
	  
	}

	@Given("user enters the following details for checkout")
	public void user_enters_the_following_details_for_checkout(io.cucumber.datatable.DataTable dataTable) throws InterruptedException {
	
		List<String> data=dataTable.asList();
		driver.findElement(By.xpath("/html/body/div/div/div/div[2]/div/form/div[1]/div[1]/input")).sendKeys(data.get(3));
		driver.findElement(By.xpath("/html/body/div/div/div/div[2]/div/form/div[1]/div[2]/input")).sendKeys(data.get(4));
		driver.findElement(By.xpath("/html/body/div/div/div/div[2]/div/form/div[1]/div[3]/input")).sendKeys(data.get(5));
		Thread.sleep(5000);
		System.out.println("Checkout details added successfully");
		driver.findElement(By.xpath("/html/body/div/div/div/div[2]/div/form/div[2]/input")).click();
	
	}

	@When("user confirm checkout")
	public void user_confirm_checkout() {
	    
		driver.findElement(By.xpath("/html/body/div/div/div/div[2]/div/div[2]/div[8]/button[2]")).click();
		System.out.println("User confirmed and checked out successfully");
	}

	@Then("user verify final confirmation messagge")
	public void user_verify_final_confirmation_messagge() {
	    
		if( driver.findElement(By.xpath("/html/body/div/div/div/div[2]/h2")).isDisplayed()){

			System.out.println("Element is Visible");

			}else{

			System.out.println("Element is InVisible");

			}
	}

	@Given("user adds one item and then remove that item to go back")
	public void user_adds_one_item_and_then_remove_that_item_to_go_back() throws InterruptedException {
		
		driver.findElement(By.xpath("/html/body/div/div/div/div[2]/div/div/div/div[1]/div[2]/div[2]/button")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("/html/body/div/div/div/div[1]/div[1]/div[3]/a/span")).click();
		Thread.sleep(5000);
		System.out.println("Required item added to the cart");
		Thread.sleep(5000);
		//driver.findElement(By.xpath("/html/body/div/div/div/div[2]/div/div[1]/div[3]/div[2]/div[2]/button")).click();
		//System.out.println("Required item removed from the cart");
		WebElement m=driver. findElement(By.id("remove-sauce-labs-backpack"));
		m.click();
		Thread.sleep(5000);
		//driver.findElement(By.xpath("/html/body/div/div/div/div[2]/div/div[1]/div[3]/div[2]/div[2]/button")).click();
		System.out.println("Required item removed from the cart");
		Thread.sleep(5000);
		driver.findElement(By.id("continue-shopping")).click();
		System.out.println("Go back to shopping");
		Thread.sleep(5000);
		//driver.findElement(By.xpath("/html/body/div/div/div/div[2]/div/div/div/div[5]/div[2]/div[2]/button")).click();
		//System.out.println("Another item added to the cart");
		
	}

	@Then("user verify final confirmation message")
	public void user_verify_final_confirmation_message() {
		if( driver.findElement(By.xpath("/html/body/div/div/div/div[2]/h2")).isDisplayed()){

			System.out.println("Element is Visible");

			}else{

			System.out.println("Element is InVisible");

			}
	}

	@Given("user sorts item low to high")
	public void user_sorts_item_low_to_high() throws InterruptedException {
	    
		Thread.sleep(5000);
		Select sort = new Select(driver.findElement(By.xpath("/html/body/div/div/div/div[1]/div[2]/div[2]/span/select")));
		sort.selectByVisibleText("Price (low to high)");
		driver.findElement(By.xpath("/html/body/div/div/div/div[2]/div/div/div/div[3]/div[2]/div[2]/button")).click();
		System.out.println("Required item added to the cart");
		
	}



	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
